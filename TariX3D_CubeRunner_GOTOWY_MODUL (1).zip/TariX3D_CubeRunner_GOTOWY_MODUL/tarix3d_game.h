#ifndef TARIX3D_GAME_H
#define TARIX3D_GAME_H

/* TariX 3D: Cube Runner — moduł gry dla grafiki TarixenOS. */
void tarix3d_game_start(void);
void tarix3d_game_frame(int left_pressed, int right_pressed, int jump_pressed, int restart_pressed);
void tarix3d_game_stop(void);

#endif
