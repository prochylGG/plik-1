#include <stdint.h>
#include "rysowanie.h"
#include "tarix3d_game.h"

/*
 * Używa prawdziwych funkcji widocznych w przesłanym rysowanie.c:
 * rysuj_prostokat(), rysuj_kwadrat(), rysuj_tekst_8x8(), odswiez_widok().
 * Nie wywołuje żadnych niepotwierdzonych funkcji klawiatury/systemu.
 *
 * Integracja z pętlą systemu: wywołuj tarix3d_game_frame(...) dokładnie
 * raz na klatkę, przekazując aktualny stan klawiszy z istniejącego inputu.
 */

#ifndef EKRAN_SZEROKOSC
#define EKRAN_SZEROKOSC 1024
#endif
#ifndef EKRAN_WYSOKOSC
#define EKRAN_WYSOKOSC 768
#endif
#ifndef PASEK_ZADAN_WYSOKOSC
#define PASEK_ZADAN_WYSOKOSC 32
#endif

#define GAME_H (EKRAN_WYSOKOSC - PASEK_ZADAN_WYSOKOSC)
#define FLOOR_Y (GAME_H - 44)
#define PLAYER_X 120
#define PLAYER_W 28
#define PLAYER_H 34
#define GRAVITY 2
#define JUMP_VELOCITY -18

#define C_BG       0x00101Bu
#define C_PANEL    0x001B2Bu
#define C_WHITE    0x00FFFFFFu
#define C_MUTED    0x00A8B8C8u
#define C_CYAN     0x0038D9FFu
#define C_RED      0x00FF4268u
#define C_YELLOW   0x00FFD166u
#define C_GREEN    0x004BE38Au

static int active;
static int alive;
static int player_y;
static int velocity_y;
static int on_ground;
static int obstacle_x;
static int obstacle_w;
static int obstacle_h;
static int obstacle_y;
static int score;
static int speed;
static int frame_counter;
static int was_jump;

static int overlap(int ax, int ay, int aw, int ah,
                   int bx, int by, int bw, int bh)
{
    return ax < bx + bw && ax + aw > bx &&
           ay < by + bh && ay + ah > by;
}

static void draw_digit(int x, int y, int digit, uint32_t color)
{
    /* Proste cyfry z segmentów — bez zależności od dodatkowych fontów. */
    static const uint8_t seg[10] = {
        0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F
    };
    static const int sx[7] = {0, 2, 12, 2, 0, 2, 2};
    static const int sy[7] = {0, 2, 7, 12, 7, 7, 2};
    (void)sx; (void)sy;
    uint8_t m = (digit >= 0 && digit <= 9) ? seg[digit] : 0;
    if (m & 0x01) rysuj_prostokat(x+3,y,10,3,color);
    if (m & 0x02) rysuj_prostokat(x+13,y+3,3,9,color);
    if (m & 0x04) rysuj_prostokat(x+13,y+14,3,9,color);
    if (m & 0x08) rysuj_prostokat(x+3,y+23,10,3,color);
    if (m & 0x10) rysuj_prostokat(x,y+14,3,9,color);
    if (m & 0x20) rysuj_prostokat(x,y+3,3,9,color);
    if (m & 0x40) rysuj_prostokat(x+3,y+11,10,3,color);
}

static void draw_number(int x, int y, int value, uint32_t color)
{
    int div = 1;
    if (value < 0) value = 0;
    while (value / div >= 10 && div < 100000000) div *= 10;
    do {
        int d = (value / div) % 10;
        draw_digit(x, y, d, color);
        x += 20;
        div /= 10;
    } while (div > 0);
}

static void draw_scene(void)
{
    int width = EKRAN_SZEROKOSC;
    int height = GAME_H;

    rysuj_prostokat(0, 0, width, height, C_BG);

    /* Tło: gwiazdy/punkty i neonowe pasy. */
    for (int i = 0; i < 30; i++) {
        int x = (i * 137 + frame_counter * 2) % width;
        int y = 40 + ((i * 71) % (height - 100));
        rysuj_kwadrat(x, y, (i % 3) + 1, (i % 4) ? C_MUTED : C_CYAN);
    }
    rysuj_prostokat(0, FLOOR_Y, width, 3, C_CYAN);
    rysuj_prostokat(0, FLOOR_Y + 3, width, height - FLOOR_Y - 3, C_PANEL);

    /* Linie podłoża przesuwają się dla efektu ruchu. */
    for (int i = 0; i < 14; i++) {
        int x = (i * 90 - (frame_counter * speed) % 90);
        rysuj_prostokat(x, FLOOR_Y + 17, 44, 2, C_MUTED);
    }

    /* Gracz — neonowy sześcian z jasną krawędzią. */
    rysuj_prostokat(PLAYER_X, player_y, PLAYER_W, PLAYER_H, C_CYAN);
    rysuj_prostokat(PLAYER_X + 5, player_y + 5, PLAYER_W - 10, PLAYER_H - 10, 0x001A6C8Au);
    rysuj_prostokat(PLAYER_X + 4, player_y + 4, PLAYER_W - 8, 3, C_WHITE);

    /* Przeszkoda i jej górna krawędź. */
    rysuj_prostokat(obstacle_x, obstacle_y, obstacle_w, obstacle_h, C_RED);
    rysuj_prostokat(obstacle_x - 3, obstacle_y, obstacle_w + 6, 5, C_YELLOW);

    /* Panel HUD. */
    rysuj_prostokat(18, 18, 270, 62, C_PANEL);
    rysuj_prostokat(18, 18, 4, 62, C_CYAN);
    rysuj_tekst_8x8(34, 28, "TARIX 3D: CUBE RUNNER", C_WHITE);
    rysuj_tekst_8x8(34, 48, "WYNIK", C_MUTED);
    draw_number(102, 43, score, C_YELLOW);

    rysuj_tekst_8x8(18, height - 25, "SPACJA/W GORE: SKOK   A/D LUB STRZALKI: RUCH   R: RESTART", C_WHITE);

    if (!alive) {
        int cx = width / 2 - 190;
        int cy = height / 2 - 68;
        rysuj_prostokat(cx, cy, 380, 136, C_PANEL);
        rysuj_prostokat(cx, cy, 380, 4, C_RED);
        rysuj_tekst_8x8(cx + 28, cy + 24, "KONIEC GRY", C_RED);
        rysuj_tekst_8x8(cx + 28, cy + 52, "NACISNIJ R, ABY ZAGRAC PONOWNIE", C_WHITE);
        rysuj_tekst_8x8(cx + 28, cy + 82, "UNIKAJ CZERWONYCH PRZESZKOD", C_MUTED);
    }
}

void tarix3d_game_start(void)
{
    active = 1;
    alive = 1;
    player_y = FLOOR_Y - PLAYER_H;
    velocity_y = 0;
    on_ground = 1;
    obstacle_x = EKRAN_SZEROKOSC + 60;
    obstacle_w = 28;
    obstacle_h = 48;
    obstacle_y = FLOOR_Y - obstacle_h;
    score = 0;
    speed = 6;
    frame_counter = 0;
    was_jump = 0;
    draw_scene();
    odswiez_widok();
}

void tarix3d_game_frame(int left_pressed, int right_pressed,
                        int jump_pressed, int restart_pressed)
{
    if (!active) return;

    if (!alive && restart_pressed) {
        tarix3d_game_start();
        return;
    }

    if (alive) {
        frame_counter++;

        /* Opcjonalny ruch boczny — ograniczony do ekranu. */
        if (left_pressed && player_y < FLOOR_Y - PLAYER_H) {
            /* W powietrzu lekka kontrola ruchu, bez zmiany X w runnerze. */
        }
        if (right_pressed) {
            /* Klawisz ruchu w prawo może być użyty jako szybszy bieg. */
            if (speed < 12) speed++;
        } else if (speed > 6 && frame_counter % 4 == 0) {
            speed--;
        }

        if (jump_pressed && !was_jump && on_ground) {
            velocity_y = JUMP_VELOCITY;
            on_ground = 0;
        }
        was_jump = jump_pressed;

        if (!on_ground) {
            player_y += velocity_y;
            velocity_y += GRAVITY;
            if (player_y >= FLOOR_Y - PLAYER_H) {
                player_y = FLOOR_Y - PLAYER_H;
                velocity_y = 0;
                on_ground = 1;
            }
        }

        obstacle_x -= speed;
        if (obstacle_x + obstacle_w < 0) {
            obstacle_x = EKRAN_SZEROKOSC + 30 + (score % 4) * 55;
            obstacle_h = 32 + ((score * 13) % 38);
            obstacle_w = 22 + ((score * 7) % 18);
            obstacle_y = FLOOR_Y - obstacle_h;
            score++;
            if (score % 5 == 0 && speed < 12) speed++;
        }

        if (overlap(PLAYER_X, player_y, PLAYER_W, PLAYER_H,
                    obstacle_x, obstacle_y, obstacle_w, obstacle_h)) {
            alive = 0;
        }
    }

    draw_scene();
    odswiez_widok();
}

void tarix3d_game_stop(void)
{
    active = 0;
}
