#ifndef TARIX3D_H
#define TARIX3D_H

void tarix3d_otworz(void);
void tarix3d_aktualizuj(void);
void tarix3d_obsluz_klawiature(void);

#endif
