# TariX 3D: Cube Runner — pliki integracyjne

Projekt jest napisany w C freestanding i korzysta z API okien/rysowania podanych w rozmowie.

## Ważne
To jest moduł gry, a nie gotowy obraz `.img` ani `.tsi`. Repozytorium TarixenOS kompiluje źródła z `kernel/*.c`, `kernel/apps/*.c` oraz `kernel/apps/*/*.c` zgodnie z `makefile`, więc plik można umieścić jako `kernel/apps/tarix3d.c`. Nagłówek umieść w `kernel/apps/tarix3d.h`.

## Integracja
1. Dodaj `#include "apps/tarix3d.h"` do pliku zawierającego `kernel_main()` (ścieżkę dopasuj do lokalizacji pliku).
2. W pętli `while (1)` dodaj:
   `tarix3d_obsluz_klawiature();`
   `tarix3d_aktualizuj();`
   przed `keyboard_discard_pending();`
3. W `kernel/graficzny/menu_start.c` lub właściwym pliku menu dodaj `#include "../apps/tarix3d.h"` (ścieżkę może wymagać korekty) i pozycję menu wywołującą `tarix3d_otworz();`.
4. Zbuduj system przez `make`.

## Sterowanie
A — lewy pas, D — prawy pas, R — restart. Po kolizji spacja, Enter lub R rozpoczyna nową grę.

## Ograniczenia pierwszego prototypu
- Aktualizacja jest oparta o liczbę iteracji pętli głównej, a nie precyzyjny timer; szybkość może zależeć od emulatora/sprzętu.
- Wygląd „3D” jest symulowany perspektywą 2D, bo dostępne API rysowania udostępnia piksele i prostokąty.
- Moduł wymaga integracji z menu i pętlą główną; samodzielnie nie będzie uruchamiany przez system.
