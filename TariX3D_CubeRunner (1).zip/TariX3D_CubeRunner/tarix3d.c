#include "tarix3d.h"
#include "../../graficzny/okno.h"
#include "../../graficzny/rysowanie.h"
#include "../../drivers/keyboard.h"

#define TOR_X 3
#define TOR_Y 5
#define TOR_SZER 3
#define PRZESZKODY 5

static struct okno gra_okno;
static int uruchomiona;
static int gra_koniec;
static int gracz_pas = 1;
static int wynik;
static int tempo;
static int klatka;
static int przeszkoda_y[PRZESZKODY];
static int przeszkoda_pas[PRZESZKODY];
static int los = 0x31A7;

static int losuj(int max)
{
    los = (los * 109 + 1021) & 0x7fffffff;
    return max ? (los % max) : 0;
}

static int tor_szerokosc(int y)
{
    int h = y - TOR_Y;
    if (h < 0) h = 0;
    return 26 + h * 3;
}

static int tor_srodek(int x, int szer)
{
    (void)x;
    return szer / 2;
}

static int pas_x(int x, int szer, int y, int pas)
{
    int szer_toru = tor_szerokosc(y);
    int srodek = tor_srodek(x, szer);
    return x + srodek - szer_toru / 2 + (szer_toru * pas) / 3;
}

static void linia(int x1, int y1, int x2, int y2, uint32_t kolor)
{
    int dx = x2 - x1;
    int dy = y2 - y1;
    int kroki = dx < 0 ? -dx : dx;
    int t = dy < 0 ? -dy : dy;
    if (t > kroki) kroki = t;
    if (!kroki) {
        rysuj_piksel(x1, y1, kolor);
        return;
    }
    for (int i = 0; i <= kroki; i++) {
        int x = x1 + dx * i / kroki;
        int y = y1 + dy * i / kroki;
        rysuj_piksel(x, y, kolor);
    }
}

static void cyfra(int x, int y, int n, uint32_t kolor)
{
    static const uint8_t wzor[10][5] = {
        {7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},
        {5,5,7,1,1},{7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},
        {7,5,7,5,7},{7,5,7,1,7}
    };
    if (n < 0 || n > 9) return;
    for (int yy = 0; yy < 5; yy++)
        for (int xx = 0; xx < 3; xx++)
            if (wzor[n][yy] & (1 << (2 - xx)))
                rysuj_prostokat(x + xx * 2, y + yy * 2, 2, 2, kolor);
}

static void napis_wynik(int x, int y, int wartosc, uint32_t kolor)
{
    int a = (wartosc / 100) % 10;
    int b = (wartosc / 10) % 10;
    int c = wartosc % 10;
    cyfra(x, y, a, kolor);
    cyfra(x + 9, y, b, kolor);
    cyfra(x + 18, y, c, kolor);
}

static void narysuj_gre(int x, int y, int szer, int wys)
{
    int dol = y + wys - 1;
    int gora = y + 18;
    if (szer < 80 || wys < 70) return;

    rysuj_prostokat(x, y, szer, wys, 0x00101828);
    rysuj_prostokat(x + 8, y + 7, 58, 17, 0x00202E43);
    napis_wynik(x + 14, y + 12, wynik, 0x00FFFFFF);

    int srodek = x + szer / 2;
    int lewy_gora = srodek - 13;
    int prawy_gora = srodek + 13;
    int lewy_dol = x + 12;
    int prawy_dol = x + szer - 12;

    linia(lewy_gora, gora, lewy_dol, dol, 0x00647C98);
    linia(prawy_gora, gora, prawy_dol, dol, 0x00647C98);
    linia(lewy_gora + 1, gora, prawy_gora - 1, gora, 0x004A6078);
    linia(lewy_dol, dol, prawy_dol, dol, 0x004A6078);

    for (int pas = 1; pas <= 2; pas++) {
        int gx = srodek - 13 + (26 * pas) / 3;
        int dx = x + 12 + (szer - 24) * pas / 3;
        linia(gx, gora, dx, dol, 0x00334860);
    }

    for (int i = 0; i < 9; i++) {
        int yy = gora + ((i * 17 + (klatka * (tempo + 1)) % 17) * (wys - 20)) / 153;
        if (yy > dol - 2) continue;
        int pol = 2 + (yy - gora) * (szer / 5) / (wys ? wys : 1);
        rysuj_prostokat(srodek - pol / 2, yy, pol, 2, 0x00283D55);
    }

    for (int i = 0; i < PRZESZKODY; i++) {
        if (przeszkoda_y[i] < 0) continue;
        int yy = gora + przeszkoda_y[i] * (wys - 38) / 100;
        if (yy < gora || yy > dol - 12) continue;
        int px = pas_x(x, szer, yy, przeszkoda_pas[i]);
        int rozmiar = 5 + (yy - gora) * 15 / (wys ? wys : 1);
        if (rozmiar < 5) rozmiar = 5;
        rysuj_prostokat(px - rozmiar / 2, yy, rozmiar, rozmiar, 0x00FF4545);
        rysuj_prostokat(px - rozmiar / 2 + 2, yy + 2, rozmiar - 4, 2, 0x00FFC0C0);
    }

    int gracz_y = dol - 27;
    int gracz_x = pas_x(x, szer, gracz_y, gracz_pas);
    rysuj_prostokat(gracz_x - 9, gracz_y + 8, 18, 4, 0x00607080);
    rysuj_prostokat(gracz_x - 7, gracz_y, 14, 14, 0x0027B7FF);
    rysuj_prostokat(gracz_x - 4, gracz_y + 3, 8, 3, 0x00DDF6FF);

    if (gra_koniec) {
        rysuj_prostokat(x + szer / 2 - 72, y + wys / 2 - 25, 144, 50, 0x00200D16);
        rysuj_prostokat(x + szer / 2 - 67, y + wys / 2 - 20, 134, 40, 0x00421A26);
        rysuj_prostokat(x + szer / 2 - 25, y + wys / 2 - 5, 50, 4, 0x00FFFFFF);
        rysuj_prostokat(x + szer / 2 - 25, y + wys / 2 + 3, 50, 4, 0x00FFFFFF);
    }
}

static void rysuj_okno_gry(int x, int y, int szer, int wys)
{
    narysuj_gre(x, y, szer, wys);
}

static void reset_gry(void)
{
    gra_koniec = 0;
    wynik = 0;
    tempo = 0;
    klatka = 0;
    gracz_pas = 1;
    for (int i = 0; i < PRZESZKODY; i++) {
        przeszkoda_y[i] = -1;
        przeszkoda_pas[i] = 1;
    }
    przeszkoda_y[0] = 12;
    przeszkoda_pas[0] = losuj(3);
}

void tarix3d_otworz(void)
{
    if (uruchomiona && gra_okno.otwarte) {
        okno_ustaw_aktywne(&gra_okno);
        okno_narysuj(&gra_okno);
        return;
    }
    reset_gry();
    okno_stworz(&gra_okno, 260, 100, 500, 430, "TariX 3D: Cube Runner", rysuj_okno_gry);
    uruchomiona = 1;
}

void tarix3d_aktualizuj(void)
{
    if (!uruchomiona || !gra_okno.otwarte || !okno_czy_aktywne(&gra_okno) || gra_koniec)
        return;

    klatka++;
    if (klatka % 4 != 0) return;

    for (int i = 0; i < PRZESZKODY; i++) {
        if (przeszkoda_y[i] < 0) {
            if (losuj(100) < 12 + tempo)
                { przeszkoda_y[i] = 0; przeszkoda_pas[i] = losuj(3); }
            continue;
        }
        przeszkoda_y[i] += 2 + tempo / 4;
        if (przeszkoda_y[i] > 100) {
            przeszkoda_y[i] = -1;
            wynik++;
            if (wynik % 8 == 0 && tempo < 12) tempo++;
        }
        if (przeszkoda_y[i] > 78 && przeszkoda_y[i] < 94 &&
            przeszkoda_pas[i] == gracz_pas) {
            gra_koniec = 1;
        }
    }
    okno_narysuj(&gra_okno);
}

void tarix3d_obsluz_klawiature(void)
{
    char znak;
    if (!uruchomiona || !gra_okno.otwarte || !okno_czy_aktywne(&gra_okno))
        return;
    if (!keyboard_try_getchar(&znak)) return;

    if (gra_koniec) {
        if (znak == ' ' || znak == '\n' || znak == 'r' || znak == 'R')
            reset_gry();
    } else {
        if ((znak == 'a' || znak == 'A') && gracz_pas > 0) gracz_pas--;
        if ((znak == 'd' || znak == 'D') && gracz_pas < 2) gracz_pas++;
        if (znak == 'r' || znak == 'R') reset_gry();
    }
    okno_narysuj(&gra_okno);
}
